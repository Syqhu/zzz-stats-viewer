---
name: キャラデータ更新 / Character Data Update
about: キャラの追加・修正・誤りの指摘
labels: data
---

## 対象キャラ / Character
<!-- 例: 星見雅、新キャラ「○○」 -->

## 種類 / Type
- [ ] 新キャラ追加
- [ ] ステータス値の修正
- [ ] 名前/属性/役割の修正
- [ ] その他

## 修正内容 / Details

### 現在の内容
```python
# 該当行をコピペ
```

### 修正後
```python
# 修正後の内容
```

## 情報源 / Source
<!-- どこの情報を参照したか (Prydwen.gg, game8.jp, wikiwiki.jp など) -->
- 

## 補足
<!-- 必要があれば -->
