---
name: バグ報告 / Bug Report
about: 不具合や問題を報告する
labels: bug
---

## 症状 / What happened?
<!-- 何が起きたか簡潔に -->

## 再現手順 / Steps to reproduce
1. 
2. 
3. 

## 期待される動作 / Expected behavior
<!-- 本来どうなるべきか -->

## 環境 / Environment
- OS: (例: Windows 11)
- Python バージョン: (`python --version` で確認)
- ZZZ Stats Viewer のバージョン:

## スクリーンショット / Screenshots
<!-- 可能であれば添付 -->

## ログ / Logs
<!-- %USERPROFILE%\.zzz_stats_cache\fetch_log.txt の内容など -->
```
ここに貼る
```
