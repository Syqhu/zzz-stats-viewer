# 📤 GitHub Desktop でアップロードするガイド

このフォルダの中身を GitHub Desktop を使ってアップロードする手順です。
画像なしでもわかるように細かく書きました。

---

## 🛠 ステップ 0: 準備 (5分)

### A) GitHubアカウントを作る
1. https://github.com/signup にアクセス
2. メアド・パスワード・ユーザー名(例: `taro123`)を入力
3. メール認証を済ませる

### B) GitHub Desktop をインストール
1. https://desktop.github.com/ からダウンロード
2. インストーラーを実行
3. 起動後、**「Sign in to GitHub.com」** をクリック
4. ブラウザが開くので GitHub にログインして承認
5. **「Configure Git」** 画面はそのまま **Continue**
6. **「Make Git Bash my default ...」** などはそのままで OK

---

## 📦 ステップ 1: ローカルにリポジトリを作る

1. GitHub Desktop を起動
2. **File → New repository...** をクリック
3. 以下を入力:

   | 項目 | 入力 |
   |---|---|
   | **Name** | `zzz-stats-viewer` |
   | **Description** | `ゼンレスゾーンゼロ 理想ステータス一覧ツール` |
   | **Local path** | お好みの場所 (例: `C:\Users\あなた\Documents\GitHub`) |
   | **Initialize this repository with a README** | ✅ チェックを**外す** |
   | **Git ignore** | `None` のまま |
   | **License** | `None` のまま (LICENSEファイルが既にあるため) |

4. **Create repository** をクリック

これで `C:\Users\あなた\Documents\GitHub\zzz-stats-viewer` に空のフォルダができます。

---

## 📁 ステップ 2: ファイルをコピー

1. **エクスプローラー**でこのフォルダ (`zzz_github_repo`) を開く
2. **中身を全選択** (Ctrl+A)
   - 含まれているもの: `zzz_stats_viewer.py`, `README.md`, `LICENSE`, `.gitignore`, `requirements.txt`, `launcher/`, `docs/`, `.github/`
3. **コピー** (Ctrl+C)
4. ステップ1で作った `zzz-stats-viewer` フォルダを開く
5. **貼り付け** (Ctrl+V)

> 💡 `.github` フォルダや `.gitignore` ファイルが見えない場合は、エクスプローラーの **表示** タブで「**隠しファイル**」にチェックを入れてください。

---

## 💾 ステップ 3: コミット (変更の記録)

1. GitHub Desktop に戻ると、左側に追加されたファイル一覧が表示されます
2. 左下の入力欄に以下を入力:
   - **Summary** (必須): `Initial commit`
   - **Description** (任意): `ZZZ Stats Viewer の初版公開`
3. **「Commit to main」** ボタンをクリック

> 💡 ボタンが押せない場合: Summaryに何か入力してください

---

## 🌐 ステップ 4: GitHubに公開

1. GitHub Desktop 画面の上部に **「Publish repository」** ボタンが現れます
2. クリックすると確認ダイアログが出ます:

   | 項目 | 設定 |
   |---|---|
   | **Name** | `zzz-stats-viewer` のまま |
   | **Description** | そのまま、または編集 |
   | **Keep this code private** | ⬜ **チェックを外す** (Publicにするため) |

3. **「Publish Repository」** をクリック

完了! 🎉

ブラウザで `https://github.com/あなたのユーザー名/zzz-stats-viewer` を開くと公開されています。

---

## ⭐ ステップ 5: リポジトリを飾る (任意・5分)

ブラウザでリポジトリページを開いて:

### A) Aboutを設定
1. 右側の **About** の右にある ⚙️ (歯車) をクリック
2. **Description**: `ゼンレスゾーンゼロのキャラ理想ステータスを表示するGUIツール`
3. **Topics** に以下を追加:
   - `python`
   - `tkinter`
   - `zenless-zone-zero`
   - `zzz`
   - `gui`
   - `desktop-app`
4. **Save changes**

### B) 自分の名前をREADMEに反映 (推奨)
1. リポジトリ画面で `README.md` をクリック
2. 鉛筆アイコン (Edit) をクリック
3. `YOURNAME` を**自分のGitHubユーザー名**に置換 (Ctrl+H で一括置換)
4. 画面下の **Commit changes** をクリック

---

## 🔄 これからの更新方法

ファイルを編集したら:

1. GitHub Desktop を開く → 変更が検知される
2. Summary に変更内容を書く (例: `南宮羽のステータス値を修正`)
3. **「Commit to main」** をクリック
4. 上部の **「Push origin」** をクリック → GitHubに反映

これだけ! コマンドラインを使わずに継続運用できます。

---

## ❓ よくある困りごと

### Q. GitHub Desktopにログインできない
→ ブラウザでGitHubにログイン状態か確認。シークレットモードを使っていると失敗することがあります。

### Q. 「Local path already exists」エラー
→ 同じ名前のフォルダが既に存在しています。別の名前にするか、既存フォルダを移動してください。

### Q. Publishボタンが灰色で押せない
→ 1回コミットしてから出現します。「Commit to main」を先に実行してください。

### Q. 公開後にプライベートに切り替えたい
→ GitHubのリポジトリ画面 → **Settings** → 一番下の **Danger Zone** → **Change repository visibility**

### Q. アップロード中エラーになる
→ ファイルサイズが大きすぎる場合 (100MB超) は不可。今回の構成では問題ないはず。`.gitignore`で除外したフォルダを再確認。

---

## 📞 困ったときは

- GitHub Desktop 公式ドキュメント (日本語): https://docs.github.com/ja/desktop
- 各種設定変更は [Settings] から後でも可能

公開成功したら、URLをぜひシェアしてください! 🎉
